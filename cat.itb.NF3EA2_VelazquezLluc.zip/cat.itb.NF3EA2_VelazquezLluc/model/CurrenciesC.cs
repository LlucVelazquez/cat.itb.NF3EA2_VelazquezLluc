﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cat.itb.NF3EA2_VelazquezLluc.model
{
	[Serializable]
	public class CurrenciesC
    {
		public string code { get; set; }
		public string name { get; set; }
		public string symbol { get; set; }
	}
}
