﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cat.itb.NF3EA2_VelazquezLluc.model
{
	[Serializable]
	public class ScoresG
    {
		public string type { get; set; }
		public ScoreG score { get; set; }
	}
}
